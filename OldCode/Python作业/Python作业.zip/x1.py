x=float(input("Please insert x:"))
y=float(input("Please insert y:"))
print(abs(x))
print((x+y+abs(x-y))/2)
# 郑晓旸 202111030007