from turtle import *

def star():
    fillcolor("red")
    pencolor("red")
    begin_fill()
    for i in range(5):
        forward(200)
        right(144)
    end_fill()
done

def main():
    star()

main()

#郑晓旸 202111030007