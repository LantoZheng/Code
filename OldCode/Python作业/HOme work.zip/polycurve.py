import numpy as np
from matplotlib import pyplot
x=np.linspace(1,10,1000)
y=x*x
pyplot.plot(x,y)
pyplot.show()
#郑晓旸 202111030007