N = 100000;
I = @(x)(4-x.^2);
x = 2 .* rand(1,N);
y = 4*rand(1,N);
sy = I(x);
int = 2*4*sum(y<=sy)/N
