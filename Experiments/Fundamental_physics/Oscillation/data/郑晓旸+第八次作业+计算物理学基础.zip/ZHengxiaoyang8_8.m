%该图形有四条迭代规则：
% 1.A = 2; B = 2i; C = 0; D = 2+2i
%P_A = P_B = P_C = P_D = 1/4;
%Z_{k+1}=(Z_{k}+A)/3 以概率P_A
%Z_{k+1}=(Z_{k}+B)/3 以概率P_B
%Z_{k+1}=(Z_{k}+C)/3 以概率P_C
%Z_{k+1}=(Z_{k}+D)/3 以概率P_D
function drawFractal(level, x, y, size)
    if level == 0
        % 绘制一个边长为size的正方形
        fill([x, x+size, x+size, x], [y, y, y+size, y+size], 'k');
        hold on;
    else
        % 计算新正方形的边长
        newSize = size / 3;
        % 递归调用，绘制四角的正方形
        for i = 0:2
            for j = 0:2
                if (i == 0 || i == 2) && (j == 0 || j == 2)
                    drawFractal(level - 1, x + i * newSize, y + j * newSize, newSize);
                end
            end
        end
    end
end

% 主函数，设置分形等级和初始正方形参数
function main()
    % 设置递归等级
    level = 6;  % 可以调整递归等级
    % 初始化图形
    figure;
    axis equal;
    axis off;
    % 绘制分形图案
    drawFractal(level, 0, 0, 1);
    hold off;
end

% 运行主函数
main();
